<footer class="main-footer">
  <div class="container">
    <div class="row" style="text-align: center;">
      <div class="col-xs-4">
        <a href="<?= base_url() ?>" class="menu-footer">
          <img src="<?= base_url('assets/flaticon/house_footer.png')?>" style=" width: 20px; height: 20px; ">
        </a>
      </div>
      <div class="col-xs-4">
        <a href="<?= base_url('event') ?>" class="menu-footer">
          <img src="<?= base_url('assets/flaticon/star_footer.png')?>" style=" width: 20px; height: 20px; ">
        </a>
      </div>
      <div class="col-xs-4">
        <a href="<?= base_url('raider/edit/'.$this->session->userdata('id')) ?>" class="menu-footer">
          <img src="<?= base_url('assets/flaticon/user_footer.png')?>" style=" width: 20px; height: 20px; ">
        </a>
      </div>
    </div>
  </div>
</footer>