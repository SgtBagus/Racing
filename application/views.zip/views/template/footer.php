<footer class="main-footer">
  <div class="container">
    <div class="row" style="text-align: center;">
      <div class="col-xs-3">
        <a href="<?= base_url() ?>" class="menu-footer" style="color:#333333">
          <img src="<?= base_url('assets/flaticon/home.png')?>" style=" width: 20px; height: 20px; ">
        </a>
      </div>
      <div class="col-xs-3">
        <a href="<?= base_url('event') ?>" class="menu-footer" style="color:#333333">
          <img src="<?= base_url('assets/flaticon/star.png')?>" style=" width: 20px; height: 20px; ">
        </a>
      </div>
      <div class="col-xs-3">
        <a href="<?= base_url('raider') ?>" class="menu-footer" style="color:#333333">
          <img src="<?= base_url('assets/flaticon/motorcycle.png')?>" style=" width: 20px; height: 20px; ">
        </a>
      </div>
      <div class="col-xs-3">
        <a href="<?= base_url('team') ?>" class="menu-footer" style="color:#333333">
          <img src="<?= base_url('assets/flaticon/user.png')?>" style=" width: 20px; height: 20px; ">
        </a>
      </div>
    </div>
  </div>
</footer>