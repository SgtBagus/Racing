<footer class="main-footer" style="padding: 10px; position: unset;">
	<div class="container" align="center" style="margin:5px 0px;">
		<strong style="font-size:14px;">Copyright © 2019 by <a href="#">Never Say Old</a> All Right Reserved</strong>
	</div>
</footer>