<footer class="main-footer-login">
	<div class="container" align="center">
		<strong>Copyright © 2019 by <a href="#">ENDURORALLY</a> All Right Reserved</strong>
	</div>
</footer>