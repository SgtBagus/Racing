<footer class="main-footer">
	<div class="container" align="center">
		<strong>Copyright © 2019 by <a href="#">Never Say Old</a> All Right Reserved</strong>
	</div>
</footer>