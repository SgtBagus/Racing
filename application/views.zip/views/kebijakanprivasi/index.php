<div class="row">
    <div class="col-md-12">
        <h3 class="box-title" align="center">Kebijakan & Privasi</h3>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-body" align="center">
                Ini tempat kontent
            </div>
        </div>
    </div>
</div>